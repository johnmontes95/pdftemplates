<?php
/**
 * Created by PhpStorm.
 * User: john
 * Date: 28/11/2018
 * Time: 10:47
 */

define('FPDF_FONTPATH','font/');
require('fpdf.php');

class PDF extends FPDF
{

    function LoadData($file)
    {
        // Leer las líneas del fichero
        $lines = file($file);
        $data = array();
        foreach($lines as $line)
            $data[] = explode(';',trim($line));
        return $data;
    }

    function BasicTable($headers, $data)
    {
        // Cabecera
        foreach ($headers as $header) {
            $this->Cell(17, 7, $header, 1, 0, 'C');
        }
        $this->Ln();
        // Datos
        $this->SetFont('Arial','',7);
            foreach($data as $row)
            {
                foreach($row as $col)
                    $this->Cell(17,7,$col,1);
                $this->Ln();
            }
    }
}

if(isset($_GET['download'])) {
    $name = $_GET['name'];
    $initDate = $_GET['initDate'];
    $finalDate = $_GET['finalDate'];
    $pdf = new PDF('P','mm','A4');
    $data= $pdf->LoadData("datos.txt");
    $pdf->SetFont('Arial','B',7);
    $pdf->AddPage();
    //$pdf->SetFont('Arial', '', 5);

    /* Header */
    $pdf->SetLeftMargin(20);
    $pdf->Cell(17,10,'Egg Laying/Inmunization Table',0,0,'L');
    $pdf->Cell(35);
    $pdf->Cell(17,10,$name,0,0,'C');
    $pdf->Cell(15);
    $pdf->Cell(17,10, 'Inmunization: ' . $initDate . '->' . $finalDate . '',0,0,'C');
    $pdf->Cell(15);
    $pdf->Ln(10);
    /* Data*/
    $titles = array('Date', 'Days', 'Tray', 'Eggs', 'Pool', 'mL');
    $pdf->BasicTable($titles, $data);
    $pdf->Output('I', $name . '.pdf');
}
?>