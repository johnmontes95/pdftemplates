
<!--<!DOCTYPE HTML>-->
<html>
<head>
    <title>Generar PDF</title>
</head>

<body>
    <h1>Print eggs laying.</h1>

    <p>Print egg laying <a href="eggsLaying.php?name=Z01_3A4_2018&initDate=22-05-2018&finalDate=22-05-2018&download=print">Z01_3A4_2018</a></p>

   <!-- <form method="get" action="eggsLaying.php">
        <label>Name</label>
        <input type="text" name="name"><br>
        <label>Initial date</label>
        <input type="date" name="initDate"><br>
        <label>Final date</label>
        <input type="date" name="finalDate"><br>
        <input type="submit" value="Print" name="download">
    </form>-->
</body>
</html>
